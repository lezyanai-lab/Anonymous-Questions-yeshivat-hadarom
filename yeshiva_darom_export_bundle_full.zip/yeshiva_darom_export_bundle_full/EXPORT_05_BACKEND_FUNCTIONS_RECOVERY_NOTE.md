# EXPORT 05 — Backend Functions (recovery note)
# ישיבת הדרום — פנייה לרב

The earlier conversation identifies these eight backend functions: `sendMessage`, `requestRabbiAccess`, `requestAccess`, `saveUserName`, `linkRabbi`, `manageRabbi`, `manageAdmin`, and `forwardMessage`. The complete original code text was not available as a retrievable attachment at the time this bundle was built, so this note is deliberately not presented as the original export. Do not use this note as implementation code.
