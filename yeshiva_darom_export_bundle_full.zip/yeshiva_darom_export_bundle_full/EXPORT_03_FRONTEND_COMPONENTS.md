\# EXPORT 03 — Frontend Components

\# ישיבת הדרום — פנייה לרב



Application-specific React components (shared UI, route guards, message card, admin tabs).



\> Standard shadcn/ui primitives (\`src/components/ui/\*\`) are **\*\*not\*\*** included — see

\> \`APP_EXPORT.md\` → "Explicitly excluded". They are unmodified library files.



\---



\## \`src/components/AppHeader.jsx\`



\`\`\`jsx

import { LogOut } from "lucide-react";

import { useAuth } from "@/lib/AuthContext";

import { Button } from "@/components/ui/button";



export default function AppHeader({ title, subtitle, icon: Icon }) {

  const { user, logout } = useAuth();



  const handleLogout = () => {

    logout(false);

    window\.location.href = "/";

  };



  return (

    \<header className="sticky top-0 z-30 bg-card/80 backdrop-blur-md border-b border-border">

      \<div className="max-w-3xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between gap-3">

        \<div className="flex items-center gap-3 min-w-0">

          \<div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center shrink-0">

            \<span className="text-primary-foreground font-bold text-base">יה\</span>

          \</div>

          \<div className="min-w-0">

            \<h1 className="text-lg font-bold text-foreground truncate">{title}\</h1>

            \<p className="text-xs text-muted-foreground truncate">{subtitle ? \`${subtitle} · ישיבת הדרום\` : "ישיבת הדרום"}\</p>

          \</div>

        \</div>

        \<div className="flex items-center gap-2 shrink-0">

          {user && (

            \<span className="hidden sm:inline text-sm text-muted-foreground">{user.email}\</span>

          )}

          \<Button variant="ghost" size="sm" onClick={handleLogout} className="text-muted-foreground hover:text-foreground">

            \<LogOut className="w-4 h-4 ml-1.5" />

            יציאה

          \</Button>

        \</div>

      \</div>

    \</header>

  );

}

\`\`\`



\---



\## \`src/components/AuthLayout.jsx\`



\`\`\`jsx

import React from "react";



export default function AuthLayout({ icon: Icon, title, subtitle, footer, children }) {

  return (

    \<div className="min-h-screen flex items-center justify-center bg-background px-4">

      \<div className="w-full max-w-md">

        \<div className="text-center mb-10">

          \<div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-primary mb-4">

            \<Icon className="w-7 h-7 text-primary-foreground" aria-hidden="true" />

          \</div>

          \<h1 className="text-3xl font-bold tracking-tight text-foreground">{title}\</h1>

          {subtitle && \<p className="text-muted-foreground mt-2">{subtitle}\</p>}

        \</div>

        \<div className="bg-card rounded-2xl shadow-sm border border-border p-8">

          {children}

        \</div>

        {footer && (

          \<p className="text-center text-sm text-muted-foreground mt-6">{footer}\</p>

        )}

      \</div>

    \</div>

  );

}

\`\`\`



\---



\## \`src/components/GoogleIcon.jsx\`



\`\`\`jsx

import React from "react";



export default function GoogleIcon({ className = "w-5 h-5" }) {

  return (

    \<svg className={className} viewBox="0 0 24 24" aria-hidden="true">

      \<path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 01-2.2 3.32v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.1z" fill="#4285F4" />

      \<path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853" />

      \<path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05" />

      \<path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335" />

    \</svg>

  );

}

\`\`\`



\---



\## \`src/components/MessageCard.jsx\`



\`\`\`jsx

import { useState } from "react";

import { Calendar, Forward, CheckCircle2, Loader2, Mail } from "lucide-react";

import { Button } from "@/components/ui/button";

import {

  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,

} from "@/components/ui/select";

import {

  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,

} from "@/components/ui/dialog";

import { base44 } from "@/api/base44Client";



const STATUS_STYLES = {

  "חדשה": "bg-blue-50 text-blue-700 border-blue-200",

  "בטיפול": "bg-amber-50 text-amber-700 border-amber-200",

  "הועברה": "bg-purple-50 text-purple-700 border-purple-200",

  "טופלה": "bg-emerald-50 text-emerald-700 border-emerald-200",

};



function formatDate(dateStr) {

  try {

    const d = new Date(dateStr);

    return d.toLocaleDateString("he-IL", { day: "numeric", month: "long", year: "numeric" }) +

      " · " + d.toLocaleTimeString("he-IL", { hour: "2-digit", minute: "2-digit" });

  } catch {

    return "";

  }

}



export default function MessageCard({ message, rabbis = [], onUpdated, showAssignedTo = false, assignedToName }) {

  const [updating, setUpdating] = useState(false);

  const [forwardOpen, setForwardOpen] = useState(false);

  const [forwarding, setForwarding] = useState(false);

  const [targetRabbiId, setTargetRabbiId] = useState("");

  const [error, setError] = useState("");



  const unread = message.is_read === false;



  const markAsRead = async () => {

    if (!unread) return;

    try {

      await base44.entities.Message.update(message.id, { is_read: true });

      onUpdated?.();

    } catch (e) {}

  };



  const handleStatus = async (newStatus) => {

    setUpdating(true);

    setError("");

    try {

      await base44.entities.Message.update(message.id, { status: newStatus, is_read: newStatus !== "חדשה" });

      onUpdated?.();

    } catch (e) {

      setError("שגיאה בעדכון הסטטוס");

    } finally {

      setUpdating(false);

    }

  };



  const handleForward = async () => {

    if (!targetRabbiId) return;

    setForwarding(true);

    setError("");

    try {

      const res = await base44.functions.invoke("forwardMessage", {

        message_id: message.id,

        target_rabbi_id: targetRabbiId,

      });

      if (res?.data?.error) {

        setError(res.data.error);

        return;

      }

      setForwardOpen(false);

      setTargetRabbiId("");

      onUpdated?.();

    } catch (e) {

      setError(e?.response?.data?.error || "שגיאה בהעברת ההודעה");

    } finally {

      setForwarding(false);

    }

  };



  return (

    \<div

      className={\`rounded-2xl border bg-card p-4 sm:p-5 shadow-sm transition-all cursor-pointer hover:shadow-md ${unread ? "border-primary/30 ring-1 ring-primary/10" : "border-border"}\`}

      onClick={markAsRead}

    >

      \<div className="flex items-center justify-between gap-2 mb-3 flex-wrap">

        \<div className="flex items-center gap-2">

          {unread && \<span className="w-2.5 h-2.5 rounded-full bg-primary shrink-0" />}

          \<span className={\`text-xs font-medium px-2.5 py-1 rounded-full border ${STATUS_STYLES[message.status] || "bg-muted text-muted-foreground border-border"}\`}>

            {message.status}

          \</span>

        \</div>

        \<span className="text-xs text-muted-foreground flex items-center gap-1.5">

          \<Calendar className="w-3.5 h-3.5" />

          {formatDate(message.created_date)}

        \</span>

      \</div>



      \<div className="flex items-center gap-2 mb-3 flex-wrap">

        \<span className="text-xs font-semibold text-primary bg-primary/5 px-2.5 py-1 rounded-lg">

          {message.category}

        \</span>

        {showAssignedTo && assignedToName && (

          \<span className="text-xs text-muted-foreground flex items-center gap-1">

            \<Mail className="w-3.5 h-3.5" />

            {assignedToName}

          \</span>

        )}

        {message.forwarded_from_email && (

          \<span className="text-xs text-purple-600 bg-purple-50 px-2.5 py-1 rounded-lg">

            הועברה מרב אחר

          \</span>

        )}

      \</div>



      \<p className="text-sm text-foreground leading-relaxed whitespace-pre-wrap mb-4">

        {message.content}

      \</p>



      {error && \<p className="text-sm text-destructive mb-3">{error}\</p>}



      \<div className="flex items-center gap-2 flex-wrap" onClick={(e) => e.stopPropagation()}>

        {message.status !== "בטיפול" && message.status !== "טופלה" && (

          \<Button size="sm" variant="outline" disabled={updating} onClick={() => handleStatus("בטיפול")}>

            {updating && \<Loader2 className="w-4 h-4 ml-1.5 animate-spin" />}

            סמן כבטיפול

          \</Button>

        )}

        {message.status !== "טופלה" && (

          \<Button size="sm" disabled={updating} onClick={() => handleStatus("טופלה")}

            className="bg-emerald-600 hover:bg-emerald-700 text-white">

            {updating ? \<Loader2 className="w-4 h-4 ml-1.5 animate-spin" /> : \<CheckCircle2 className="w-4 h-4 ml-1.5" />}

            סמן כטופלה

          \</Button>

        )}

        {message.status !== "חדשה" && (

          \<Button size="sm" variant="ghost" disabled={updating} onClick={() => handleStatus("חדשה")} className="text-muted-foreground">

            סמן כחדשה

          \</Button>

        )}

        {rabbis.length > 0 && message.status !== "טופלה" && (

          \<Button size="sm" variant="ghost" onClick={() => setForwardOpen(true)} className="text-muted-foreground">

            \<Forward className="w-4 h-4 ml-1.5" />

            העבר לרב אחר

          \</Button>

        )}

      \</div>



      \<Dialog open={forwardOpen} onOpenChange={setForwardOpen}>

        \<DialogContent className="max-w-sm">

          \<DialogHeader>

            \<DialogTitle>העברת ההודעה לרב אחר\</DialogTitle>

          \</DialogHeader>

          \<p className="text-sm text-muted-foreground mb-2">

            הרב שייבחר יקבל גישה להודעה, והיא תוסר מרשימת ההודעות שלך.

          \</p>

          \<Select value={targetRabbiId} onValueChange={setTargetRabbiId}>

            \<SelectTrigger className="h-12">\<SelectValue placeholder="בחר רב מאושר" />\</SelectTrigger>

            \<SelectContent>

              {rabbis.map(r => (

                \<SelectItem key={r.id} value={r.id}>{r.display_name}\</SelectItem>

              ))}

            \</SelectContent>

          \</Select>

          {error && \<p className="text-sm text-destructive mt-2">{error}\</p>}

          \<DialogFooter className="gap-2">

            \<Button variant="outline" onClick={() => { setForwardOpen(false); setError(""); }}>ביטול\</Button>

            \<Button onClick={handleForward} disabled={!targetRabbiId || forwarding}>

              {forwarding ? \<Loader2 className="w-4 h-4 ml-1.5 animate-spin" /> : \<Forward className="w-4 h-4 ml-1.5" />}

              העבר הודעה

            \</Button>

          \</DialogFooter>

        \</DialogContent>

      \</Dialog>

    \</div>

  );

}

\`\`\`



\---



\## \`src/components/ProtectedRoute.jsx\`



\`\`\`jsx

import { useEffect } from 'react';

import { Outlet } from 'react-router-dom';

import { useAuth } from '@/lib/AuthContext';

import UserNotRegisteredError from '@/components/UserNotRegisteredError';



const DefaultFallback = () => (

  \<div className="fixed inset-0 flex items-center justify-center">

    \<div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin">\</div>

  \</div>

);



export default function ProtectedRoute({ fallback = \<DefaultFallback />, unauthenticatedElement }) {

  const { isAuthenticated, isLoadingAuth, authChecked, authError, checkUserAuth } = useAuth();



  useEffect(() => {

    if (!authChecked && !isLoadingAuth) {

      checkUserAuth();

    }

  }, [authChecked, isLoadingAuth, checkUserAuth]);



  if (isLoadingAuth || !authChecked) {

    return fallback;

  }



  if (authError) {

    if (authError.type === 'user_not_registered') {

      return \<UserNotRegisteredError />;

    }

    return unauthenticatedElement;

  }



  if (!isAuthenticated) {

    return unauthenticatedElement;

  }



  return \<Outlet />;

}

\`\`\`



\---



\## \`src/components/RabbiRoute.jsx\`



\`\`\`jsx

import { useState, useEffect } from "react";

import { Navigate } from "react-router-dom";

import { base44 } from "@/api/base44Client";

import { useAuth } from "@/lib/AuthContext";

import UserAccessScreen from "@/components/UserAccessScreen";



export default function RabbiRoute({ children }) {

  const { user, isAuthenticated, authChecked, isLoadingAuth, logout } = useAuth();

  const [data, setData] = useState(null);

  const [loading, setLoading] = useState(true);

  const [refreshKey, setRefreshKey] = useState(0);



  useEffect(() => {

    if (!authChecked || isLoadingAuth) return;

    if (!isAuthenticated || !user) { setLoading(false); return; }

    (async () => {

      try {

        const res = await base44.functions.invoke("requestRabbiAccess", {});

        setData(res?.data || res);

      } catch (e) {

        setData({ status: "error" });

      } finally {

        setLoading(false);

      }

    })();

  }, [authChecked, isLoadingAuth, isAuthenticated, user, refreshKey]);



  if (isLoadingAuth || !authChecked || loading) {

    return (

      \<div className="fixed inset-0 flex items-center justify-center bg-background">

        \<div className="w-8 h-8 border-4 border-secondary border-t-primary rounded-full animate-spin">\</div>

      \</div>

    );

  }



  if (!isAuthenticated || !user) {

    return \<Navigate to="/login" replace />;

  }



  if (data?.status === "admin") {

    // אם המשתמש הרגע קודם למנהל, נדרשת טעינה מחדש כדי לרענן את עצם המשתמש

    if (data.just_promoted) {

      window\.location.href = "/admin";

      return null;

    }

    return \<Navigate to="/admin" replace />;

  }



  if (data?.status === "approved") {

    return children;

  }



  return (

    \<UserAccessScreen

      data={data}

      onRefresh={() => { setLoading(true); setRefreshKey(k => k + 1); }}

      onLogout={() => logout()}

    />

  );

}

\`\`\`



\---



\## \`src/components/RoleRoute.jsx\`



\`\`\`jsx

import { Navigate } from 'react-router-dom';

import { useAuth } from '@/lib/AuthContext';



export default function RoleRoute({ allowedRoles, redirectTo = '/', children }) {

  const { user, isAuthenticated, authChecked, isLoadingAuth } = useAuth();



  if (isLoadingAuth || !authChecked) {

    return (

      \<div className="fixed inset-0 flex items-center justify-center bg-background">

        \<div className="w-8 h-8 border-4 border-secondary border-t-primary rounded-full animate-spin">\</div>

      \</div>

    );

  }



  if (!isAuthenticated || !user) {

    return \<Navigate to="/login" replace />;

  }



  if (!allowedRoles.includes(user.role)) {

    return \<Navigate to={redirectTo} replace />;

  }



  return children;

}

\`\`\`



\---



\## \`src/components/ScrollToTop.jsx\`



\`\`\`jsx

import { useEffect } from "react";

import { useLocation, useNavigationType } from "react-router-dom";



const getHashId = (hash) => {

  const rawId = hash.slice(1);



  try {

    return decodeURIComponent(rawId);

  } catch {

    return rawId;

  }

};



export default function ScrollToTop() {

  const { pathname, hash } = useLocation();

  const navigationType = useNavigationType();



  useEffect(() => {

    if (navigationType === "POP") return;



    if (hash) {

      const id = getHashId(hash);

      const timer = window\.setTimeout(() => {

        document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });

      }, 50);

      return () => window\.clearTimeout(timer);

    }



    window\.scrollTo({ top: 0, left: 0, behavior: "instant" });

  }, [pathname, hash, navigationType]);



  return null;

}

\`\`\`



\---



\## \`src/components/UserAccessScreen.jsx\`



\`\`\`jsx

import { useState } from "react";

import { User, Shield, Clock, ShieldCheck, ShieldX, Loader2, LogOut, Mail, CheckCircle2 } from "lucide-react";

import { base44 } from "@/api/base44Client";

import { Button } from "@/components/ui/button";

import { Input } from "@/components/ui/input";

import { toast } from "sonner";



export default function UserAccessScreen({ data, onRefresh, onLogout }) {

  const [name, setName] = useState(data?.display_name || "");

  const [savingName, setSavingName] = useState(false);

  const [requesting, setRequesting] = useState(null);



  const handleSaveName = async () => {

    if (!name.trim() || name.trim().length < 2) { toast.error("נא להזין שם תקין (לפחות 2 תווים)"); return; }

    setSavingName(true);

    try {

      const res = await base44.functions.invoke("saveUserName", { display_name: name.trim() });

      if (res?.data?.error) { toast.error(res.data.error); return; }

      toast.success("השם נשמר");

      onRefresh();

    } catch (e) { toast.error("שמירת השם נכשלה"); }

    finally { setSavingName(false); }

  };



  const handleRequest = async (type) => {

    setRequesting(type);

    try {

      const res = await base44.functions.invoke("requestAccess", { request_type: type });

      if (res?.data?.error) { toast.error(res.data.error); return; }

      toast.success(type === "rabbi" ? "בקשת גישת רב נשלחה למנהל" : "בקשת גישת מנהל נשלחה למנהל הראשי");

      onRefresh();

    } catch (e) { toast.error("שליחת הבקשה נכשלה"); }

    finally { setRequesting(null); }

  };



  const has_name = data?.has_name;

  const rabbiStatus = data?.rabbi_request?.status;

  const adminStatus = data?.admin_request?.status;



  return (

    \<div className="min-h-screen bg-gradient-to-b from-background to-secondary/40 flex items-center justify-center px-4 py-8">

      \<div className="max-w-md w-full">

        \<div className="text-center mb-6">

          \<div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-primary mb-4">

            \<span className="text-primary-foreground font-bold text-2xl">יה\</span>

          \</div>

          \<h1 className="text-2xl font-bold text-foreground mb-1">ישיבת הדרום\</h1>

        \</div>



        \<div className="rounded-2xl bg-card border border-border shadow-sm p-6 space-y-5">

          {!has_name ? (

            \<div>

              \<h2 className="font-semibold text-foreground mb-1">שלום, נא להזין את שמך\</h2>

              \<p className="text-sm text-muted-foreground mb-3 leading-relaxed">

                השם יוצג למנהל הישיבה לצורך אישור וקישור לרב. זהות חשבון ה-Google שלך נשמרת בנפרד.

              \</p>

              \<Input value={name} onChange={(e) => setName(e.target.value)} className="h-12" placeholder="שם מלא" onKeyDown={(e) => e.key === "Enter" && handleSaveName()} />

              \<Button onClick={handleSaveName} disabled={savingName} className="w-full h-12 mt-3">

                {savingName ? \<Loader2 className="w-4 h-4 ml-2 animate-spin" /> : \<CheckCircle2 className="w-4 h-4 ml-2" />}

                שמור שם

              \</Button>

            \</div>

          ) : (

            <>

              \<div className="flex items-center gap-3 pb-4 border-b border-border">

                \<div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center shrink-0">

                  \<User className="w-5 h-5 text-primary-foreground" />

                \</div>

                \<div className="min-w-0">

                  \<p className="font-semibold text-foreground truncate">{data.display_name}\</p>

                  \<p className="text-xs text-muted-foreground flex items-center gap-1 truncate">

                    \<Mail className="w-3 h-3" /> {data.google_email}

                  \</p>

                \</div>

              \</div>



              {/\* Rabbi access \*/}

              \<div className="space-y-2">

                \<div className="flex items-center gap-2">

                  \<Shield className="w-4 h-4 text-primary" />

                  \<h3 className="text-sm font-semibold text-foreground">גישת רב\</h3>

                \</div>

                {rabbiStatus === "pending" && (

                  \<div className="flex items-center gap-2 text-sm text-amber-700 bg-amber-50 rounded-lg px-3 py-2.5">

                    \<Clock className="w-4 h-4 shrink-0" /> הבקשה ממתינה לאישור וקישור לרב על ידי המנהל

                  \</div>

                )}

                {rabbiStatus === "rejected" && (

                  \<div className="space-y-2">

                    \<div className="flex items-center gap-2 text-sm text-destructive bg-destructive/10 rounded-lg px-3 py-2.5">

                      \<ShieldX className="w-4 h-4 shrink-0" /> הבקשה נדחתה. ניתן לשלוח בקשה חדשה.

                    \</div>

                    \<Button variant="outline" size="sm" disabled={requesting === "rabbi"} onClick={() => handleRequest("rabbi")} className="w-full h-10">

                      {requesting === "rabbi" ? \<Loader2 className="w-4 h-4 ml-2 animate-spin" /> : \<Shield className="w-4 h-4 ml-2" />}

                      בקש גישת רב שוב

                    \</Button>

                  \</div>

                )}

                {!rabbiStatus && (

                  \<Button variant="outline" disabled={requesting === "rabbi"} onClick={() => handleRequest("rabbi")} className="w-full h-11">

                    {requesting === "rabbi" ? \<Loader2 className="w-4 h-4 ml-2 animate-spin" /> : \<Shield className="w-4 h-4 ml-2" />}

                    בקש גישת רב

                  \</Button>

                )}

              \</div>



              {/\* Admin access \*/}

              \<div className="space-y-2">

                \<div className="flex items-center gap-2">

                  \<ShieldCheck className="w-4 h-4 text-primary" />

                  \<h3 className="text-sm font-semibold text-foreground">גישת מנהל\</h3>

                \</div>

                {adminStatus === "pending" && (

                  \<div className="flex items-center gap-2 text-sm text-amber-700 bg-amber-50 rounded-lg px-3 py-2.5">

                    \<Clock className="w-4 h-4 shrink-0" /> הבקשה ממתינה לאישור המנהל הראשי

                  \</div>

                )}

                {adminStatus === "rejected" && (

                  \<div className="space-y-2">

                    \<div className="flex items-center gap-2 text-sm text-destructive bg-destructive/10 rounded-lg px-3 py-2.5">

                      \<ShieldX className="w-4 h-4 shrink-0" /> הבקשה נדחתה. ניתן לשלוח בקשה חדשה.

                    \</div>

                    \<Button variant="outline" size="sm" disabled={requesting === "admin"} onClick={() => handleRequest("admin")} className="w-full h-10">

                      {requesting === "admin" ? \<Loader2 className="w-4 h-4 ml-2 animate-spin" /> : \<ShieldCheck className="w-4 h-4 ml-2" />}

                      בקש גישת מנהל שוב

                    \</Button>

                  \</div>

                )}

                {!adminStatus && (

                  \<Button variant="outline" disabled={requesting === "admin"} onClick={() => handleRequest("admin")} className="w-full h-11">

                    {requesting === "admin" ? \<Loader2 className="w-4 h-4 ml-2 animate-spin" /> : \<ShieldCheck className="w-4 h-4 ml-2" />}

                    בקש גישת מנהל

                  \</Button>

                )}

              \</div>

            \</>

          )}

        \</div>



        \<div className="text-center mt-4">

          \<Button variant="ghost" size="sm" onClick={onLogout} className="text-muted-foreground">

            \<LogOut className="w-4 h-4 ml-1.5" /> יציאה

          \</Button>

        \</div>

      \</div>

    \</div>

  );

}

\`\`\`



\---



\## \`src/components/UserNotRegisteredError.jsx\`



\`\`\`jsx

import React from 'react';



const UserNotRegisteredError = () => {

  return (

    \<div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-b from-white to-slate-50">

      \<div className="max-w-md w-full p-8 bg-white rounded-lg shadow-lg border border-slate-100">

        \<div className="text-center">

          \<div className="inline-flex items-center justify-center w-16 h-16 mb-6 rounded-full bg-orange-100">

            \<svg className="w-8 h-8 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">

              \<path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />

            \</svg>

          \</div>

          \<h1 className="text-3xl font-bold text-slate-900 mb-4">Access Restricted\</h1>

          \<p className="text-slate-600 mb-8">

            You are not registered to use this application. Please contact the app administrator to request access.

          \</p>

          \<div className="p-4 bg-slate-50 rounded-md text-sm text-slate-600">

            \<p>If you believe this is an error, you can:\</p>

            \<ul className="list-disc list-inside mt-2 space-y-1">

              \<li>Verify you are logged in with the correct account\</li>

              \<li>Contact the app administrator for access\</li>

              \<li>Try logging out and back in again\</li>

            \</ul>

          \</div>

        \</div>

      \</div>

    \</div>

  );

};



export default UserNotRegisteredError;

\`\`\`



\---



\## \`src/components/admin/AdminRequests.jsx\`



\`\`\`jsx

import { useState, useEffect, useCallback } from "react";

import { Shield, Check, X, Loader2, Mail, User, ShieldX, Info, Clock } from "lucide-react";

import { base44 } from "@/api/base44Client";

import { Button } from "@/components/ui/button";

import { toast } from "sonner";



function formatDate(dateStr) {

  try { return new Date(dateStr).toLocaleDateString("he-IL", { day: "numeric", month: "long", year: "numeric", hour: "2-digit", minute: "2-digit" }); }

  catch { return ""; }

}



export default function AdminRequests({ isMainAdmin, onChanged }) {

  const [requests, setRequests] = useState([]);

  const [loading, setLoading] = useState(true);

  const [acting, setActing] = useState(null);



  const load = useCallback(async () => {

    setLoading(true);

    try {

      const { items } = await base44.entities.AccessRequest.filter(

        { request_type: "admin" },

        { sort: "-created_date", limit: 100 }

      );

      setRequests(items || []);

    } catch (e) { console.error(e); }

    finally { setLoading(false); }

  }, []);



  useEffect(() => { load(); }, [load]);



  const handleAction = async (req, action) => {

    setActing(req.id);

    try {

      const res = await base44.functions.invoke("manageAdmin", { request_id: req.id, action });

      if (res?.data?.error) { toast.error(res.data.error); return; }

      toast.success(action === "approve" ? "הוענקה גישת מנהל" : action === "reject" ? "הבקשה נדחתה" : "גישת המנהל בוטלה");

      load();

      onChanged?.();

    } catch (e) {

      toast.error("הפעולה נכשלה");

    } finally { setActing(null); }

  };



  if (loading) {

    return \<div className="flex items-center justify-center py-16">\<Loader2 className="w-7 h-7 animate-spin text-muted-foreground" />\</div>;

  }



  const pending = requests.filter(r => r.status === "pending");

  const approved = requests.filter(r => r.status === "approved");



  return (

    \<div className="space-y-5">

      {!isMainAdmin && (

        \<div className="flex items-start gap-2 rounded-xl bg-secondary/60 p-3 text-sm text-muted-foreground">

          \<Info className="w-4 h-4 shrink-0 mt-0.5" />

          \<p>רק המנהל הראשי יכול לאשר ולבטל מנהלים. ניתן לצפות בבקשות אך לא לפעול.\</p>

        \</div>

      )}



      {/\* Pending \*/}

      \<section>

        \<h2 className="text-sm font-semibold text-foreground mb-3 flex items-center gap-2">

          \<Clock className="w-4 h-4" /> בקשות ממתינות ({pending.length})

        \</h2>

        {pending.length === 0 ? (

          \<p className="text-sm text-muted-foreground text-center py-6">אין בקשות מנהל ממתינות\</p>

        ) : (

          \<div className="space-y-3">

            {pending.map((r) => (

              \<div key={r.id} className="rounded-2xl border border-border bg-card p-4">

                \<div className="flex items-start justify-between gap-3 flex-wrap">

                  \<div className="min-w-0">

                    \<div className="flex items-center gap-2">

                      \<User className="w-4 h-4 text-muted-foreground" />

                      \<p className="font-semibold text-foreground">{r.entered_name}\</p>

                    \</div>

                    \<p className="text-xs text-muted-foreground mt-1 flex items-center gap-1">

                      \<Mail className="w-3 h-3" /> {r.google_email}

                    \</p>

                    \<p className="text-xs text-muted-foreground mt-1">{formatDate(r.created_date)}\</p>

                  \</div>

                  {isMainAdmin && (

                    \<div className="flex items-center gap-2 shrink-0">

                      \<Button size="sm" disabled={acting === r.id} onClick={() => handleAction(r, "approve")}

                        className="bg-emerald-600 hover:bg-emerald-700 text-white">

                        {acting === r.id ? \<Loader2 className="w-4 h-4 ml-1.5 animate-spin" /> : \<Check className="w-4 h-4 ml-1.5" />}

                        אשר

                      \</Button>

                      \<Button size="sm" variant="outline" disabled={acting === r.id} onClick={() => handleAction(r, "reject")}>

                        {acting === r.id ? \<Loader2 className="w-4 h-4 ml-1.5 animate-spin" /> : \<X className="w-4 h-4 ml-1.5" />}

                        דחה

                      \</Button>

                    \</div>

                  )}

                \</div>

              \</div>

            ))}

          \</div>

        )}

      \</section>



      {/\* Approved (can revoke) \*/}

      {approved.length > 0 && (

        \<section>

          \<h2 className="text-sm font-semibold text-foreground mb-3 flex items-center gap-2">

            \<Shield className="w-4 h-4" /> מנהלים פעילים שאושרו דרך המערכת ({approved.length})

          \</h2>

          \<div className="space-y-3">

            {approved.map((r) => (

              \<div key={r.id} className="rounded-2xl border border-border bg-card p-4">

                \<div className="flex items-start justify-between gap-3 flex-wrap">

                  \<div className="min-w-0">

                    \<div className="flex items-center gap-2">

                      \<User className="w-4 h-4 text-muted-foreground" />

                      \<p className="font-semibold text-foreground">{r.entered_name}\</p>

                      \<span className="text-xs bg-emerald-50 text-emerald-700 border border-emerald-200 px-2 py-0.5 rounded-full">מנהל\</span>

                    \</div>

                    \<p className="text-xs text-muted-foreground mt-1 flex items-center gap-1">

                      \<Mail className="w-3 h-3" /> {r.google_email}

                    \</p>

                    \<p className="text-xs text-muted-foreground mt-1">אושר על ידי {r.decided_by_email} · {formatDate(r.decided_date)}\</p>

                  \</div>

                  {isMainAdmin && (

                    \<Button size="sm" variant="outline" disabled={acting === r.id} onClick={() => handleAction(r, "revoke")} className="text-destructive border-destructive/30 hover:bg-destructive/10">

                      {acting === r.id ? \<Loader2 className="w-4 h-4 ml-1.5 animate-spin" /> : \<ShieldX className="w-4 h-4 ml-1.5" />}

                      בטל הרשאה

                    \</Button>

                  )}

                \</div>

              \</div>

            ))}

          \</div>

        \</section>

      )}

    \</div>

  );

}

\`\`\`



\---



\## \`src/components/admin/AuditTab.jsx\`



\`\`\`jsx

import { useState, useEffect, useCallback } from "react";

import { ScrollText, Loader2 } from "lucide-react";

import { base44 } from "@/api/base44Client";



const ACTION_LABELS = {

  approve_rabbi: "אישור רב",

  reject_rabbi: "דחיית רב",

  revoke_rabbi: "ביטול הרשאת רב",

  reactivate_rabbi: "הפעלת רב מחדש",

  grant_admin: "הענקת מנהל",

  revoke_admin: "ביטול מנהל",

};



function formatDate(dateStr) {

  try {

    return new Date(dateStr).toLocaleDateString("he-IL", { day: "numeric", month: "long", year: "numeric", hour: "2-digit", minute: "2-digit" });

  } catch { return ""; }

}



export default function AuditTab() {

  const [logs, setLogs] = useState([]);

  const [loading, setLoading] = useState(true);



  const load = useCallback(async () => {

    setLoading(true);

    try {

      const { items } = await base44.entities.AuditLog.filter({}, { sort: "-created_date", limit: 50 });

      setLogs(items || []);

    } catch (e) { console.error(e); }

    finally { setLoading(false); }

  }, []);



  useEffect(() => { load(); }, [load]);



  if (loading) {

    return \<div className="flex items-center justify-center py-16">\<Loader2 className="w-7 h-7 animate-spin text-muted-foreground" />\</div>;

  }



  if (logs.length === 0) {

    return (

      \<div className="text-center py-16">

        \<div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-secondary mb-3">

          \<ScrollText className="w-7 h-7 text-muted-foreground" />

        \</div>

        \<p className="text-muted-foreground">אין אירועים מתועדים עדיין\</p>

      \</div>

    );

  }



  return (

    \<div className="space-y-2">

      {logs.map((log) => (

        \<div key={log.id} className="rounded-xl border border-border bg-card p-3 flex items-start gap-3">

          \<div className="w-2 h-2 rounded-full bg-primary mt-1.5 shrink-0" />

          \<div className="min-w-0 flex-1">

            \<div className="flex items-center justify-between gap-2 flex-wrap">

              \<p className="text-sm font-medium text-foreground">{ACTION_LABELS[log.action] || log.action}\</p>

              \<span className="text-xs text-muted-foreground">{formatDate(log.created_date)}\</span>

            \</div>

            \<p className="text-xs text-muted-foreground mt-0.5">

              {log.target_email && \<span>נבצע על: {log.target_email} · \</span>}

              על ידי: {log.performed_by_email}

            \</p>

            {log.details && \<p className="text-xs text-muted-foreground mt-0.5">{log.details}\</p>}

          \</div>

        \</div>

      ))}

    \</div>

  );

}

\`\`\`



\---



\## \`src/components/admin/MessagesTab.jsx\`



\`\`\`jsx

import { useState, useEffect, useCallback } from "react";

import { MessageSquare, Loader2 } from "lucide-react";

import { base44 } from "@/api/base44Client";

import MessageCard from "@/components/MessageCard";



export default function MessagesTab({ onChanged }) {

  const [messages, setMessages] = useState([]);

  const [rabbis, setRabbis] = useState([]);

  const [loading, setLoading] = useState(true);

  const [refreshKey, setRefreshKey] = useState(0);



  const load = useCallback(async () => {

    setLoading(true);

    try {

      const [msgRes, rabbiRes] = await Promise.all([

        base44.entities.Message.filter({}, { sort: "-created_date", limit: 50 }),

        base44.entities.Rabbi.filter({ approval_status: "approved", active: true }, { limit: 100 }),

      ]);

      setMessages(msgRes.items || []);

      setRabbis(rabbiRes.items || []);

    } catch (e) { console.error(e); }

    finally { setLoading(false); }

  }, []);



  useEffect(() => { load(); }, [load, refreshKey]);



  const rabbiNameByEmail = (email) => {

    const r = rabbis.find(r => r.email === email);

    return r ? r.display_name : email || "—";

  };



  if (loading) {

    return \<div className="flex items-center justify-center py-16">\<Loader2 className="w-7 h-7 animate-spin text-muted-foreground" />\</div>;

  }



  if (messages.length === 0) {

    return (

      \<div className="text-center py-16">

        \<div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-secondary mb-3">

          \<MessageSquare className="w-7 h-7 text-muted-foreground" />

        \</div>

        \<p className="text-muted-foreground">אין הודעות במערכת\</p>

      \</div>

    );

  }



  return (

    \<div className="space-y-3">

      {messages.map((m) => (

        \<MessageCard

          key={m.id}

          message={m}

          rabbis={rabbis}

          onUpdated={() => { setRefreshKey(k => k + 1); onChanged?.(); }}

          showAssignedTo

          assignedToName={rabbiNameByEmail(m.assigned_to_email)}

        />

      ))}

    \</div>

  );

}

\`\`\`



\---



\## \`src/components/admin/PendingRequests.jsx\`



\`\`\`jsx

import { useState, useEffect, useCallback } from "react";

import { UserCheck, Check, Link2, Plus, Loader2, Mail, Clock, User } from "lucide-react";

import { base44 } from "@/api/base44Client";

import { Button } from "@/components/ui/button";

import { Input } from "@/components/ui/input";

import { Textarea } from "@/components/ui/textarea";

import { Label } from "@/components/ui/label";

import {

  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,

} from "@/components/ui/select";

import {

  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,

} from "@/components/ui/dialog";

import { toast } from "sonner";



function formatDate(dateStr) {

  try { return new Date(dateStr).toLocaleDateString("he-IL", { day: "numeric", month: "long", hour: "2-digit", minute: "2-digit" }); }

  catch { return ""; }

}



export default function PendingRequests({ onChanged }) {

  const [pending, setPending] = useState([]);

  const [rabbis, setRabbis] = useState([]);

  const [loading, setLoading] = useState(true);

  const [linkDialog, setLinkDialog] = useState(null);

  const [acting, setActing] = useState(null);

  const [linkMode, setLinkMode] = useState("existing");

  const [selectedRabbi, setSelectedRabbi] = useState("");

  const [newRabbiName, setNewRabbiName] = useState("");

  const [newRabbiDesc, setNewRabbiDesc] = useState("");



  const load = useCallback(async () => {

    setLoading(true);

    try {

      const [reqRes, rabbiRes] = await Promise.all([

        base44.entities.AccessRequest.filter(

          { request_type: "rabbi", status: "pending" },

          { sort: "created_date", limit: 100 }

        ),

        base44.entities.Rabbi.filter({}, { sort: "display_name", limit: 100 }),

      ]);

      setPending(reqRes.items || []);

      setRabbis(rabbiRes.items || []);

    } catch (e) { console.error(e); }

    finally { setLoading(false); }

  }, []);



  useEffect(() => { load(); }, [load]);



  const openLink = (req) => {

    setLinkDialog(req);

    setLinkMode("existing");

    setSelectedRabbi("");

    setNewRabbiName(req.entered_name || "");

    setNewRabbiDesc("");

  };



  const handleLink = async () => {

    if (!linkDialog) return;

    if (linkMode === "existing" && !selectedRabbi) { toast.error("נא לבחור רב"); return; }

    if (linkMode === "new" && !newRabbiName.trim()) { toast.error("נא להזין שם לרב"); return; }

    setActing(linkDialog.id);

    try {

      const payload = { request_id: linkDialog.id };

      if (linkMode === "existing") {

        payload.rabbi_id = selectedRabbi;

      } else {

        payload.display_name = newRabbiName.trim();

        payload.description = newRabbiDesc.trim();

      }

      const res = await base44.functions.invoke("linkRabbi", payload);

      if (res?.data?.error) { toast.error(res.data.error); return; }

      toast.success("החשבון קושר לרב ואושר");

      setLinkDialog(null);

      load();

      onChanged?.();

    } catch (e) { toast.error("הקישור נכשל"); }

    finally { setActing(null); }

  };



  if (loading) {

    return \<div className="flex items-center justify-center py-16">\<Loader2 className="w-7 h-7 animate-spin text-muted-foreground" />\</div>;

  }



  if (pending.length === 0) {

    return (

      \<div className="text-center py-16">

        \<div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-secondary mb-3">

          \<UserCheck className="w-7 h-7 text-muted-foreground" />

        \</div>

        \<p className="text-muted-foreground">אין בקשות רבנים ממתינות\</p>

      \</div>

    );

  }



  return (

    \<div className="space-y-3">

      \<p className="text-sm text-muted-foreground mb-2">{pending.length} בקשות רבנים ממתינות לקישור ואישור\</p>

      {pending.map((r) => (

        \<div key={r.id} className="rounded-2xl border border-border bg-card p-4">

          \<div className="flex items-start justify-between gap-3 flex-wrap">

            \<div className="min-w-0">

              \<div className="flex items-center gap-2">

                \<User className="w-4 h-4 text-muted-foreground" />

                \<p className="font-semibold text-foreground">{r.entered_name}\</p>

              \</div>

              \<p className="text-xs text-muted-foreground mt-1 flex items-center gap-1">

                \<Mail className="w-3 h-3" /> {r.google_email}

              \</p>

              \<p className="text-xs text-muted-foreground mt-1 flex items-center gap-1">

                \<Clock className="w-3 h-3" /> {formatDate(r.created_date)}

              \</p>

            \</div>

            \<Button size="sm" onClick={() => openLink(r)} className="shrink-0">

              \<Link2 className="w-4 h-4 ml-1.5" />

              קשר לרב

            \</Button>

          \</div>

        \</div>

      ))}



      \<Dialog open={!!linkDialog} onOpenChange={(o) => !o && setLinkDialog(null)}>

        \<DialogContent className="max-w-md">

          \<DialogHeader>

            \<DialogTitle>קישור חשבון לרב\</DialogTitle>

          \</DialogHeader>

          {linkDialog && (

            \<div className="space-y-4">

              \<div className="rounded-lg bg-secondary/50 p-3 text-sm">

                \<p className="font-medium text-foreground">{linkDialog.entered_name}\</p>

                \<p className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5">

                  \<Mail className="w-3 h-3" /> {linkDialog.google_email}

                \</p>

              \</div>



              \<div className="flex gap-2">

                \<button

                  onClick={() => setLinkMode("existing")}

                  className={\`flex-1 py-2.5 rounded-xl text-sm font-medium border-2 transition-all ${linkMode === "existing" ? "border-primary bg-primary/5 text-primary" : "border-border text-muted-foreground"}\`}

                >

                  קשר לרב קיים

                \</button>

                \<button

                  onClick={() => setLinkMode("new")}

                  className={\`flex-1 py-2.5 rounded-xl text-sm font-medium border-2 transition-all ${linkMode === "new" ? "border-primary bg-primary/5 text-primary" : "border-border text-muted-foreground"}\`}

                >

                  צור רב חדש

                \</button>

              \</div>



              {linkMode === "existing" ? (

                \<div className="space-y-2">

                  \<Label>בחר רב מהרשימה\</Label>

                  \<Select value={selectedRabbi} onValueChange={setSelectedRabbi}>

                    \<SelectTrigger className="h-12">\<SelectValue placeholder="בחר רב..." />\</SelectTrigger>

                    \<SelectContent>

                      {rabbis.map(rb => (

                        \<SelectItem key={rb.id} value={rb.id}>

                          {rb.display_name}{rb.email ? \` (${rb.email})\` : ""}

                        \</SelectItem>

                      ))}

                    \</SelectContent>

                  \</Select>

                  {rabbis.length === 0 && \<p className="text-xs text-muted-foreground">אין רבנים ברשימה — צור רב חדש.\</p>}

                \</div>

              ) : (

                \<div className="space-y-3">

                  \<div className="space-y-2">

                    \<Label>שם הרב המוצג לתלמידים\</Label>

                    \<Input value={newRabbiName} onChange={(e) => setNewRabbiName(e.target.value)} className="h-12" placeholder="הרב..." />

                  \</div>

                  \<div className="space-y-2">

                    \<Label>תיאור קצר (לא חובה)\</Label>

                    \<Textarea value={newRabbiDesc} onChange={(e) => setNewRabbiDesc(e.target.value)} rows={2} />

                  \</div>

                \</div>

              )}

            \</div>

          )}

          \<DialogFooter className="gap-2">

            \<Button variant="outline" onClick={() => setLinkDialog(null)}>ביטול\</Button>

            \<Button onClick={handleLink} disabled={acting}>

              {acting ? \<Loader2 className="w-4 h-4 ml-1.5 animate-spin" /> : \<Check className="w-4 h-4 ml-1.5" />}

              קשר ואשר

            \</Button>

          \</DialogFooter>

        \</DialogContent>

      \</Dialog>

    \</div>

  );

}

\`\`\`



\---



\## \`src/components/admin/RabbisManagement.jsx\`



\`\`\`jsx

import { useState, useEffect, useCallback } from "react";

import { Users, Plus, Power, Trash2, Pencil, Mail, Search, Loader2, ShieldX, RotateCcw, ShieldCheck } from "lucide-react";

import { base44 } from "@/api/base44Client";

import { useAuth } from "@/lib/AuthContext";

import { Button } from "@/components/ui/button";

import { Input } from "@/components/ui/input";

import { Textarea } from "@/components/ui/textarea";

import { Label } from "@/components/ui/label";

import {

  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,

} from "@/components/ui/dialog";

import { toast } from "sonner";



const STATUS_LABELS = {

  approved: { label: "מאושר", cls: "bg-emerald-50 text-emerald-700 border-emerald-200" },

  revoked: { label: "הרשאה בוטלה", cls: "bg-destructive/10 text-destructive border-destructive/20" },

  rejected: { label: "נדחה", cls: "bg-amber-50 text-amber-700 border-amber-200" },

};



function formatDate(dateStr) {

  try { return new Date(dateStr).toLocaleDateString("he-IL", { day: "numeric", month: "long", year: "numeric" }); }

  catch { return ""; }

}



export default function RabbisManagement({ onChanged }) {

  const { user } = useAuth();

  const [rabbis, setRabbis] = useState([]);

  const [loading, setLoading] = useState(true);

  const [search, setSearch] = useState("");

  const [createOpen, setCreateOpen] = useState(false);

  const [editing, setEditing] = useState(null);

  const [acting, setActing] = useState(null);

  const [form, setForm] = useState({ display_name: "", description: "", email: "", active: true });

  const [saving, setSaving] = useState(false);



  const load = useCallback(async () => {

    setLoading(true);

    try {

      const query = { approval_status: { $ne: "pending" } };

      const trimmed = search.trim();

      if (trimmed) {

        query.$or = [

          { display_name: { $regex: trimmed, $options: "i" } },

          { email: { $regex: trimmed, $options: "i" } },

        ];

      }

      const { items } = await base44.entities.Rabbi.filter(query, { sort: "-created_date", limit: 100 });

      setRabbis(items || []);

    } catch (e) { console.error(e); }

    finally { setLoading(false); }

  }, [search]);



  useEffect(() => { load(); }, [load]);



  const openCreate = () => {

    setEditing(null);

    setForm({ display_name: "", description: "", email: "", active: true });

    setCreateOpen(true);

  };



  const openEdit = (rabbi) => {

    setEditing(rabbi);

    setForm({ display_name: rabbi.display_name, description: rabbi.description || "", email: rabbi.email || "", active: rabbi.active });

    setCreateOpen(true);

  };



  const handleSave = async () => {

    if (!form.display_name.trim() || !form.email.trim()) { toast.error("נא למלא שם וכתובת מייל"); return; }

    if (!form.email.includes("@")) { toast.error("כתובת המייל אינה תקינה"); return; }

    setSaving(true);

    try {

      const now = new Date().toISOString();

      if (editing) {

        await base44.entities.Rabbi.update(editing.id, {

          display_name: form.display_name.trim(),

          description: form.description.trim(),

          email: form.email.trim(),

          active: form.active,

        });

        toast.success("הרב עודכן");

      } else {

        await base44.entities.Rabbi.create({

          display_name: form.display_name.trim(),

          description: form.description.trim(),

          email: form.email.trim(),

          active: form.active,

          approval_status: "approved",

          approved_by_email: user.email,

          approved_date: now,

        });

        toast.success("הרב נוסף ואושר");

      }

      setCreateOpen(false);

      load();

      onChanged?.();

    } catch (e) { toast.error("השמירה נכשלה"); }

    finally { setSaving(false); }

  };



  const handleManage = async (rabbi, action) => {

    setActing(rabbi.id);

    try {

      const res = await base44.functions.invoke("manageRabbi", { rabbi_id: rabbi.id, action });

      if (res?.data?.error) { toast.error(res.data.error); return; }

      toast.success(action === "revoke" ? "הרשאת הרב בוטלה" : "הרב הופעל מחדש");

      load();

      onChanged?.();

    } catch (e) { toast.error("הפעולה נכשלה"); }

    finally { setActing(null); }

  };



  const handleDelete = async (rabbi) => {

    if (!confirm(\`למחוק את "${rabbi.display_name}"?\`)) return;

    try {

      await base44.entities.Rabbi.delete(rabbi.id);

      toast.success("הרב נמחק");

      load();

    } catch (e) { toast.error("המחיקה נכשלה"); }

  };



  return (

    \<div>

      \<div className="flex gap-2 mb-4">

        \<Button onClick={openCreate} className="flex-1 h-12 bg-primary hover:bg-primary/90">

          \<Plus className="w-4 h-4 ml-1.5" /> הוספת רב

        \</Button>

      \</div>



      \<div className="relative mb-4">

        \<Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />

        \<Input

          value={search}

          onChange={(e) => setSearch(e.target.value)}

          placeholder="חיפוש לפי שם או כתובת מייל..."

          className="pr-10 h-12"

        />

      \</div>



      {loading ? (

        \<div className="flex items-center justify-center py-16">\<Loader2 className="w-7 h-7 animate-spin text-muted-foreground" />\</div>

      ) : rabbis.length === 0 ? (

        \<p className="text-center text-muted-foreground py-10">אין רבנים מאושרים עדיין\</p>

      ) : (

        \<div className="space-y-3">

          {rabbis.map((r) => {

            const st = STATUS_LABELS[r.approval_status] || {};

            return (

              \<div key={r.id} className={\`rounded-2xl border bg-card p-4 ${r.approval_status === "approved" && r.active ? "border-border" : "border-border opacity-70"}\`}>

                \<div className="flex items-start justify-between gap-3 flex-wrap">

                  \<div className="min-w-0">

                    \<div className="flex items-center gap-2 flex-wrap">

                      \<p className="font-semibold text-foreground">{r.display_name}\</p>

                      {st.label && \<span className={\`text-xs px-2 py-0.5 rounded-full border ${st.cls}\`}>{st.label}\</span>}

                      {r.approval_status === "approved" && !r.active && \<span className="text-xs bg-muted text-muted-foreground px-2 py-0.5 rounded-full">מוסתר מתלמידים\</span>}

                    \</div>

                    {r.description && \<p className="text-sm text-muted-foreground mt-1">{r.description}\</p>}

                    {r.email && \<p className="text-xs text-muted-foreground mt-1 flex items-center gap-1">\<Mail className="w-3 h-3" /> {r.email}\</p>}

                    {r.approved_date && (

                      \<p className="text-xs text-muted-foreground mt-1">

                        אושר על ידי {r.approved_by_email || "—"} ב-{formatDate(r.approved_date)}

                      \</p>

                    )}

                  \</div>

                  \<div className="flex items-center gap-1 shrink-0">

                    \<Button size="icon" variant="ghost" onClick={() => openEdit(r)} title="עריכה">\<Pencil className="w-4 h-4" />\</Button>

                    {r.approval_status === "approved" && (

                      \<Button size="icon" variant="ghost" disabled={acting === r.id} onClick={() => handleManage(r, "revoke")} title="ביטול הרשאה" className="text-destructive">

                        {acting === r.id ? \<Loader2 className="w-4 h-4 animate-spin" /> : \<ShieldX className="w-4 h-4" />}

                      \</Button>

                    )}

                    {r.approval_status === "revoked" && (

                      \<Button size="icon" variant="ghost" disabled={acting === r.id} onClick={() => handleManage(r, "reactivate")} title="הפעלה מחדש" className="text-emerald-600">

                        {acting === r.id ? \<Loader2 className="w-4 h-4 animate-spin" /> : \<RotateCcw className="w-4 h-4" />}

                      \</Button>

                    )}

                    \<Button size="icon" variant="ghost" onClick={() => handleDelete(r)} title="מחיקה" className="text-destructive">\<Trash2 className="w-4 h-4" />\</Button>

                  \</div>

                \</div>

              \</div>

            );

          })}

        \</div>

      )}



      \<Dialog open={createOpen} onOpenChange={setCreateOpen}>

        \<DialogContent className="max-w-md">

          \<DialogHeader>\<DialogTitle>{editing ? "עריכת רב" : "הוספת רב מאושר"}\</DialogTitle>\</DialogHeader>

          \<div className="space-y-4">

            \<div className="space-y-2">

              \<Label>שם הרב המוצג לתלמידים\</Label>

              \<Input value={form.display_name} onChange={(e) => setForm({ ...form, display_name: e.target.value })} className="h-12" placeholder="הרב..." />

            \</div>

            \<div className="space-y-2">

              \<Label>כתובת מייל (חשבון Google של הרב)\</Label>

              \<Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="h-12" placeholder="rabbi\@gmail.com" dir="ltr" />

              \<p className="text-xs text-muted-foreground">הרב יוכל להיכנס באמצעות חשבון Google זה\</p>

            \</div>

            \<div className="space-y-2">

              \<Label>תיאור קצר (לא חובה)\</Label>

              \<Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} rows={2} placeholder="לדוגמה: רב הישיבה, מומחה ל..." />

            \</div>

            \<label className="flex items-center gap-2 cursor-pointer">

              \<input type="checkbox" checked={form.active} onChange={(e) => setForm({ ...form, active: e.target.checked })} className="w-4 h-4" />

              \<span className="text-sm">פעיל (מוצג לתלמידים)\</span>

            \</label>

          \</div>

          \<DialogFooter className="gap-2">

            \<Button variant="outline" onClick={() => setCreateOpen(false)}>ביטול\</Button>

            \<Button onClick={handleSave} disabled={saving}>

              {saving && \<Loader2 className="w-4 h-4 ml-1.5 animate-spin" />}

              {editing ? "שמור שינויים" : "הוסף ואשר"}

            \</Button>

          \</DialogFooter>

        \</DialogContent>

      \</Dialog>

    \</div>

  );

}

\`\`