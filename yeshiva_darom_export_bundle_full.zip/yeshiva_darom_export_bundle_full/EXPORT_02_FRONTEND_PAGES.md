\# EXPORT 02 — Frontend Pages

\# ישיבת הדרום — פנייה לרב



Every page routed in \`src/App.jsx\`, plus the 404 page lives in \`src/lib/PageNotFound.jsx\`

(exported in \`EXPORT_04_LIB_API_AND_HOOKS.md\`).



\| File | Route | Purpose |

\|---|---|---|

\| \`src/pages/StudentHome.jsx\` | \`/\` | Anonymous student → rabbi message form |

\| \`src/pages/Login.jsx\` | \`/login\` | Google sign-in for rabbis & admins |

\| \`src/pages/RabbiDashboard.jsx\` | \`/rabbi\` | Rabbi inbox (tabs, unread count, realtime refresh) |

\| \`src/pages/AdminDashboard.jsx\` | \`/admin\` | Admin area with 5 tabs |



\> **\*\*Not included here:\*\*** \`src/pages/ForgotPassword.jsx\`, \`src/pages/Register.jsx\`,

\> \`src/pages/ResetPassword.jsx\` and \`src/pages/OAuthConsent.jsx\` exist in the project as

\> unmodified platform boilerplate. They are **\*\*not routed\*\*** in \`src/App.jsx\` and this app

\> uses Google sign-in only. See \`APP_EXPORT.md\` → "Explicitly excluded".



\---



\## \`src/pages/StudentHome.jsx\`



\`\`\`jsx

import { useState, useEffect } from "react";

import { Send, CheckCircle2, Shield, Loader2, Lock, LogIn, ShieldCheck } from "lucide-react";

import { Link } from "react-router-dom";

import { base44 } from "@/api/base44Client";

import { Button } from "@/components/ui/button";

import { Textarea } from "@/components/ui/textarea";



const CATEGORIES = [

{ value: "שאלה תורנית", label: "שאלה תורנית" },

{ value: "עניין אישי", label: "עניין אישי" },

{ value: "בעיה חברתית", label: "בעיה חברתית" },

{ value: "דיווח חשוב", label: "דיווח חשוב" },

{ value: "אחר", label: "אחר" }];





export default function StudentHome() {

  const [rabbis, setRabbis] = useState([]);

  const [loadingRabbis, setLoadingRabbis] = useState(true);

  const [selectedRabbi, setSelectedRabbi] = useState(null);

  const [category, setCategory] = useState("");

  const [content, setContent] = useState("");

  const [submitting, setSubmitting] = useState(false);

  const [success, setSuccess] = useState(false);

  const [error, setError] = useState("");



  useEffect(() => {

    (async () => {

      try {

        const { items } = await base44.entities.Rabbi.filter(

          { active: true, approval_status: "approved" },

          { sort: "display_name", limit: 100 }

        );

        setRabbis(items || []);

      } catch (e) {

        setError("טעינת רשימת הרבנים נכשלה");

      } finally {

        setLoadingRabbis(false);

      }

    })();

  }, []);



  const canSubmit = selectedRabbi && category && content.trim().length >= 10 && !submitting;



  const handleSubmit = async (e) => {

    e?.preventDefault();

    if (!canSubmit) return;

    setSubmitting(true);

    setError("");

    try {

      await base44.functions.invoke("sendMessage", {

        rabbi_id: selectedRabbi,

        category,

        content

      });

      setSuccess(true);

      setSelectedRabbi(null);

      setCategory("");

      setContent("");

    } catch (e) {

      setError(e?.response?.data?.error || "שליחת ההודעה נכשלה, נא לנסות שוב");

    } finally {

      setSubmitting(false);

    }

  };



  const resetSuccess = () => setSuccess(false);



  return (

    \<div className="min-h-screen bg-gradient-to-b from-background to-secondary/40">

      \<div className="max-w-2xl mx-auto px-4 sm:px-6 py-8 sm:py-12">

        {/\* Header \*/}

        \<div className="text-center mb-8">







          \<h1 className="text-3xl sm:text-4xl font-bold text-foreground mb-2">ישיבת הדרום\</h1>

          \<p className="text-base text-muted-foreground max-w-md mx-auto leading-relaxed">

            פנייה אנונימית לרבני הישיבה באופן פרטי ומאובטח

          \</p>

          \<div className="inline-flex items-center gap-1.5 mt-4 text-xs text-muted-foreground bg-secondary/60 px-3 py-1.5 rounded-full">

            \<Lock className="w-3.5 h-3.5" />

            שליחה אנונימית · ללא פרטים מזהים

          \</div>

        \</div>



        {success ?

        \<div className="rounded-2xl bg-card border border-border shadow-sm p-8 text-center">

            \<div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-emerald-50 mb-4">

              \<CheckCircle2 className="w-9 h-9 text-emerald-600" />

            \</div>

            \<h2 className="text-xl font-bold text-foreground mb-2">ההודעה התקבלה בהצלחה\</h2>

            \<p className="text-sm text-muted-foreground mb-6 leading-relaxed">

              תודה על הפנייה. הרב יטפל בהודעה בהקדם האפשרי.\<br />

              השליחה בוצעה ללא חשיפת פרטים מזהים.

            \</p>

            \<Button onClick={resetSuccess} className="bg-primary hover:bg-primary/90 text-primary-foreground h-12 px-8">

              שליחת הודעה נוספת

            \</Button>

          \</div> :



        \<form onSubmit={handleSubmit} className="space-y-6">

            {/\* Step 1: Choose rabbi \*/}

            \<section>

              \<h2 className="text-sm font-semibold text-foreground mb-3 flex items-center gap-2">

                \<span className="w-6 h-6 rounded-full bg-primary text-primary-foreground text-xs flex items-center justify-center">1\</span>

                בחירת רב

              \</h2>

              {loadingRabbis ?

            \<div className="flex items-center justify-center py-8">

                  \<Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />

                \</div> :

            rabbis.length === 0 ?

            \<p className="text-sm text-muted-foreground text-center py-6">אין רבנים זמינים כעת\</p> :



            \<div className="grid grid-cols-1 sm:grid-cols-2 gap-3">

                  {rabbis.map((r) =>

              \<button

                key={r.id}

                type="button"

                onClick={() => setSelectedRabbi(r.id)}

                className={\`text-right rounded-2xl border p-4 transition-all ${

                selectedRabbi === r.id ?

                "border-primary bg-primary/5 ring-2 ring-primary/20" :

                "border-border bg-card hover:border-primary/30"}\`

                }>



                      \<div className="flex items-start gap-3">

                        \<div className={\`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${selectedRabbi === r.id ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"}\`}>

                          \<span className="text-sm font-bold">{r.display_name?.charAt(0) || "?"}\</span>

                        \</div>

                        \<div className="min-w-0">

                          \<p className="font-semibold text-foreground text-sm">{r.display_name}\</p>

                          {r.description && \<p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">{r.description}\</p>}

                        \</div>

                      \</div>

                    \</button>

              )}

                \</div>

            }

            \</section>



            {/\* Step 2: Category \*/}

            \<section>

              \<h2 className="text-sm font-semibold text-foreground mb-3 flex items-center gap-2">

                \<span className="w-6 h-6 rounded-full bg-primary text-primary-foreground text-xs flex items-center justify-center">2\</span>

                נושא הפנייה

              \</h2>

              \<div className="flex flex-wrap gap-2">

                {CATEGORIES.map((c) =>

              \<button

                key={c.value}

                type="button"

                onClick={() => setCategory(c.value)}

                className={\`px-4 py-2.5 rounded-xl text-sm font-medium transition-all ${

                category === c.value ?

                "bg-primary text-primary-foreground border-2 border-primary" :

                "bg-card text-foreground border-2 border-border hover:border-primary/30"}\`

                }>



                    {c.label}

                  \</button>

              )}

              \</div>

            \</section>



            {/\* Step 3: Message \*/}

            \<section>

              \<h2 className="text-sm font-semibold text-foreground mb-3 flex items-center gap-2">

                \<span className="w-6 h-6 rounded-full bg-primary text-primary-foreground text-xs flex items-center justify-center">3\</span>

                תוכן ההודעה

              \</h2>

              \<Textarea

              value={content}

              onChange={(e) => setContent(e.target.value)}

              placeholder="כתוב כאן את הודעתך..."

              rows={6}

              maxLength={5000}

              className="resize-none text-base leading-relaxed" />



              \<div className="flex items-center justify-between mt-1.5">

                \<p className="text-xs text-muted-foreground">{content.length}/5000\</p>

                {content.trim().length > 0 && content.trim().length < 10 &&

              \<p className="text-xs text-muted-foreground">מינימום 10 תווים\</p>

              }

              \</div>

            \</section>



            {error &&

          \<div className="rounded-xl bg-destructive/10 text-destructive text-sm p-3 text-center">

                {error}

              \</div>

          }



            \<Button

            type="submit"

            disabled={!canSubmit}

            className="w-full h-14 text-base font-semibold bg-primary hover:bg-primary/90 text-primary-foreground rounded-2xl">



              {submitting ?

            <>\<Loader2 className="w-5 h-5 ml-2 animate-spin" /> שולח...\</> :



            <>\<Send className="w-5 h-5 ml-2" /> שליחת הודעה\</>

            }

            \</Button>



            \<p className="text-xs text-muted-foreground text-center flex items-center justify-center gap-1.5">

              \<Shield className="w-3.5 h-3.5" />

              המערכת אינה אוספת שם, טלפון או כתובת מייל

            \</p>

          \</form>

        }



        {/\* Footer buttons \*/}

        \<div className="mt-10 pt-6 border-t border-border flex flex-col sm:flex-row items-center justify-center gap-3">

          \<Link to="/login" className="w-full sm:w-auto">

            \<Button variant="outline" className="w-full h-11 text-sm">

              \<LogIn className="w-4 h-4 ml-2" />

              כניסת רבנים

            \</Button>

          \</Link>

          \<Link to="/login" className="w-full sm:w-auto">

            \<Button variant="outline" className="w-full h-11 text-sm">

              \<ShieldCheck className="w-4 h-4 ml-2" />

              כניסת מנהלים

            \</Button>

          \</Link>

        \</div>

      \</div>

    \</div>);



}

\`\`\`



\---



\## \`src/pages/Login.jsx\`



\`\`\`jsx

import { useState, useEffect } from "react";

import { Link, Navigate } from "react-router-dom";

import { base44 } from "@/api/base44Client";

import { Button } from "@/components/ui/button";

import { BookOpen, Loader2, LogIn } from "lucide-react";

import AuthLayout from "@/components/AuthLayout";

import GoogleIcon from "@/components/GoogleIcon";

import { useAuth } from "@/lib/AuthContext";



export default function Login() {

  const { isAuthenticated, authChecked, isLoadingAuth, user } = useAuth();

  const [loading, setLoading] = useState(false);

  const [error, setError] = useState("");



  // משתמש שכבר מחובר — הפניה לאזור שלו

  if (authChecked && !isLoadingAuth && isAuthenticated && user) {

    return \<Navigate to="/rabbi" replace />;

  }



  const handleGoogle = () => {

    setError("");

    setLoading(true);

    base44.auth.loginWithProvider("google", "/rabbi");

  };



  return (

    \<AuthLayout

      icon={BookOpen}

      title="ישיבת הדרום"

      subtitle="כניסת רבנים ומנהלים"

      footer={

        \<Link to="/" className="text-primary font-medium hover:underline">

          חזרה למסך התלמידים

        \</Link>

      }

    >

      \<div className="text-center mb-6">

        \<p className="text-sm text-muted-foreground leading-relaxed">

          כניסה למערכת ישיבת הדרום באמצעות חשבון Google בלבד.\<br />

          רב חדש יקבל סטטוס "ממתין לאישור" עד לאישור המנהל.

        \</p>

      \</div>



      {error && (

        \<div className="mb-4 p-3 rounded-lg bg-destructive/10 text-destructive text-sm text-center">

          {error}

        \</div>

      )}



      \<Button

        onClick={handleGoogle}

        disabled={loading}

        className="w-full h-12 font-medium bg-white text-foreground border border-border hover:bg-secondary"

      >

        {loading ? (

          \<Loader2 className="w-4 h-4 ml-2 animate-spin" />

        ) : (

          \<GoogleIcon className="w-5 h-5 ml-2" />

        )}

        כניסה באמצעות Google

      \</Button>



      \<div className="mt-6 space-y-3">

        \<div className="flex items-center justify-center gap-2 text-xs text-muted-foreground">

          \<LogIn className="w-3.5 h-3.5" />

          \<span>תלמידים אינם זקוקים לחשבון — ניתן לשלוח הודעה מהמסך הראשי\</span>

        \</div>

        \<p className="text-center text-xs text-muted-foreground">

          החיבור נשמר אוטומטית באופן מאובטח בדפדפן — אין צורך להתחבר מחדש בכל ביקור

        \</p>

      \</div>

    \</AuthLayout>

  );

}

\`\`\`



\---



\## \`src/pages/RabbiDashboard.jsx\`



\`\`\`jsx

import { useState, useEffect, useCallback } from "react";

import { Inbox, Loader2, MessageSquare, Bell } from "lucide-react";

import { base44 } from "@/api/base44Client";

import { useAuth } from "@/lib/AuthContext";

import AppHeader from "@/components/AppHeader";

import MessageCard from "@/components/MessageCard";



const STATUS_TABS = ["הכל", "חדשה", "בטיפול", "הועברה", "טופלה"];



export default function RabbiDashboard() {

  const { user } = useAuth();

  const [messages, setMessages] = useState([]);

  const [rabbis, setRabbis] = useState([]);

  const [unreadCount, setUnreadCount] = useState(0);

  const [loading, setLoading] = useState(true);

  const [activeTab, setActiveTab] = useState("הכל");

  const [refreshKey, setRefreshKey] = useState(0);



  const load = useCallback(async () => {

    if (!user?.email) return;

    setLoading(true);

    try {

      const query = { assigned_to_email: user.email };

      if (activeTab !== "הכל") query.status = activeTab;

      const [msgRes, rabbiRes, count] = await Promise.all([

        base44.entities.Message.filter(query, { sort: "-created_date", limit: 50 }),

        base44.entities.Rabbi.filter({ approval_status: "approved", active: true }, { limit: 100 }),

        base44.entities.Message.count({ assigned_to_email: user.email, is_read: { $ne: true } }),

      ]);

      setMessages(msgRes.items || []);

      setRabbis(rabbiRes.items || []);

      setUnreadCount(count || 0);

    } catch (e) {

      console.error(e);

    } finally {

      setLoading(false);

    }

  }, [user, activeTab]);



  useEffect(() => { load(); }, [load, refreshKey]);



  // רענון אוטומטי בזמן-אמת

  useEffect(() => {

    const unsub = base44.entities.Message.subscribe(() => setRefreshKey(k => k + 1));

    return unsub;

  }, []);



  const refresh = () => setRefreshKey(k => k + 1);



  return (

    \<div className="min-h-screen bg-background">

      \<AppHeader title="אזור הרבנים" subtitle="תיבת הודעות" icon={Inbox} />



      \<div className="max-w-3xl mx-auto px-4 sm:px-6 py-6">

        {/\* Unread banner \*/}

        {unreadCount > 0 && (

          \<div className="flex items-center gap-2 bg-primary/5 border border-primary/20 rounded-xl px-4 py-3 mb-5">

            \<Bell className="w-5 h-5 text-primary shrink-0" />

            \<p className="text-sm text-primary font-medium">

              {unreadCount} {unreadCount === 1 ? "הודעה חדשה" : "הודעות חדשות"} ממתינות לקריאה

            \</p>

          \</div>

        )}



        \<div className="flex gap-2 overflow-x-auto pb-2 mb-5 -mx-4 px-4 sm:mx-0 sm:px-0">

          {STATUS_TABS.map((tab) => (

            \<button

              key={tab}

              onClick={() => setActiveTab(tab)}

              className={\`px-4 py-2 rounded-xl text-sm font-medium whitespace-nowrap transition-all ${

                activeTab === tab

                  ? "bg-primary text-primary-foreground"

                  : "bg-card text-muted-foreground border border-border hover:text-foreground"

              }\`}

            >

              {tab}

            \</button>

          ))}

        \</div>



        {loading ? (

          \<div className="flex items-center justify-center py-16">

            \<Loader2 className="w-7 h-7 animate-spin text-muted-foreground" />

          \</div>

        ) : messages.length === 0 ? (

          \<div className="text-center py-16">

            \<div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-secondary mb-3">

              \<MessageSquare className="w-7 h-7 text-muted-foreground" />

            \</div>

            \<p className="text-muted-foreground">אין הודעות בקטגוריה זו\</p>

          \</div>

        ) : (

          \<div className="space-y-3">

            {messages.map((m) => (

              \<MessageCard key={m.id} message={m} rabbis={rabbis} onUpdated={refresh} />

            ))}

          \</div>

        )}

      \</div>

    \</div>

  );

}

\`\`\`



\---



\## \`src/pages/AdminDashboard.jsx\`



\`\`\`jsx

import { useState, useEffect } from "react";

import { Settings, Users, MessageSquare, UserCheck, Shield, ScrollText, ShieldCheck } from "lucide-react";

import { base44 } from "@/api/base44Client";

import { useAuth } from "@/lib/AuthContext";

import AppHeader from "@/components/AppHeader";

import PendingRequests from "@/components/admin/PendingRequests";

import AdminRequests from "@/components/admin/AdminRequests";

import RabbisManagement from "@/components/admin/RabbisManagement";

import MessagesTab from "@/components/admin/MessagesTab";

import AuditTab from "@/components/admin/AuditTab";



const TABS = [

  { key: "pending", label: "בקשות רבנים", icon: UserCheck },

  { key: "admins", label: "בקשות מנהלים", icon: Shield },

  { key: "rabbis", label: "רבנים", icon: Users },

  { key: "messages", label: "הודעות", icon: MessageSquare },

  { key: "audit", label: "יומן אירועים", icon: ScrollText },

];



export default function AdminDashboard() {

  const { user } = useAuth();

  const [tab, setTab] = useState("pending");

  const [isMainAdmin, setIsMainAdmin] = useState(false);

  const [ownerEmail, setOwnerEmail] = useState("");

  const [refreshKey, setRefreshKey] = useState(0);

  const refresh = () => setRefreshKey(k => k + 1);



  useEffect(() => {

    (async () => {

      try {

        const { items } = await base44.entities.Settings.filter({}, { limit: 1 });

        if (items?.length > 0) {

          setOwnerEmail(items[0].owner_email);

          setIsMainAdmin(items[0].owner_email === user?.email);

        }

      } catch (e) {}

    })();

  }, [user]);



  return (

    \<div className="min-h-screen bg-background">

      \<AppHeader title="אזור הניהול" subtitle={isMainAdmin ? "מנהל ראשי" : "מנהל"} icon={Settings} />

      \<div className="max-w-3xl mx-auto px-4 sm:px-6 py-6">

        {isMainAdmin && ownerEmail && (

          \<div className="flex items-center gap-2 rounded-xl bg-primary/5 border border-primary/20 px-4 py-2.5 mb-4 text-sm">

            \<ShieldCheck className="w-4 h-4 text-primary shrink-0" />

            \<span className="text-muted-foreground">המנהל הראשי (בעל האפליקציה):\</span>

            \<span className="font-semibold text-foreground break-all">{ownerEmail}\</span>

          \</div>

        )}

        \<div className="flex gap-2 overflow-x-auto pb-2 mb-5 -mx-4 px-4 sm:mx-0 sm:px-0">

          {TABS.map(({ key, label, icon: Icon }) => (

            \<button key={key} onClick={() => setTab(key)}

              className={\`flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-sm font-medium whitespace-nowrap transition-all ${tab === key ? "bg-primary text-primary-foreground" : "bg-card border border-border text-muted-foreground"}\`}>

              \<Icon className="w-4 h-4" /> {label}

            \</button>

          ))}

        \</div>

        {tab === "pending" && \<PendingRequests onChanged={refresh} />}

        {tab === "admins" && \<AdminRequests isMainAdmin={isMainAdmin} onChanged={refresh} />}

        {tab === "rabbis" && \<RabbisManagement onChanged={refresh} />}

        {tab === "messages" && \<MessagesTab onChanged={refresh} />}

        {tab === "audit" && \<AuditTab />}

      \</div>

    \</div>

  );

}

\`\`