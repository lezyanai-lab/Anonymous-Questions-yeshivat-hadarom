# EXPORT 06 — Data Model & Access Rules (recovery note)
# ישיבת הדרום — פנייה לרב

The earlier conversation identifies six entities/schemas: `Rabbi`, `Message`, `AccessRequest`, `AuditLog`, `Settings`, and `User`, with associated access rules and configuration. The complete original schema/config text was not available as a retrievable attachment at the time this bundle was built, so this note is deliberately not presented as the original export. Do not use this note as the original schema source.
