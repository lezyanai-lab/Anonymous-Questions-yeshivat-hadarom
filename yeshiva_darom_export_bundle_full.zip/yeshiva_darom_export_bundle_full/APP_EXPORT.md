# APP_EXPORT — ישיבת הדרום — פנייה לרב

## Contents
1. `EXPORT_01_APP_SHELL_AND_CONFIG.md` — app shell, routes, and build configuration.
2. `EXPORT_02_FRONTEND_PAGES.md` — frontend pages.
3. `EXPORT_03_FRONTEND_COMPONENTS.md` — frontend components.
4. `EXPORT_04_LIB_API_AND_HOOKS.md` — SDK client, auth context, helpers, and hooks.
5. `EXPORT_05_BACKEND_FUNCTIONS_RECOVERY_NOTE.md` — **recovery note only; not the full original backend code**.
6. `EXPORT_06_DATA_MODEL_AND_ACCESS_RULES_RECOVERY_NOTE.md` — **recovery note only; not the full original schemas/config**.

## Important completeness note
This ZIP contains seven Markdown files, but it is not a complete source export: files 05 and 06 are recovery notes because their full original contents were not available as files to package. Do not treat those notes as implementation code or as the original data schemas. Files 01–04 contain the available recovered source exports.
